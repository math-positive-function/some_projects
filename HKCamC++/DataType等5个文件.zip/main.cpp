#include <iostream>
#include <cstring>
using namespace std;
#include "HCNetSDK.h"

int main()
{
    NET_DVR_Init();

    NET_DVR_USER_LOGIN_INFO struLoginInfo;

    NET_DVR_DEVICEINFO_V40 struDeviceInfo;

    strncpy(struLoginInfo.sDeviceAddress, "192.168.101.65", strlen("192.168.101.65") + 1);
    strncpy(struLoginInfo.sUserName, "admin", strlen("admin") + 1);
    strncpy(struLoginInfo.sPassword, "njcm123456", strlen("njcm123456") + 1);
    struLoginInfo.bUseAsynLogin = 0;
    struLoginInfo.byUseTransport = 0;
    struLoginInfo.wPort = 8000;
    LONG lHandle = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfo);
    if (lHandle < 0)
    {
        std::cout << NET_DVR_GetErrorMsg() << std::endl;
        return -1;
    }

    std::cout << lHandle << std::endl;
   NET_DVR_SetSDKInitCfg(NET_SDK_INIT_CFG_SDK_PATH, const_cast<char*>("./"));

    NET_DVR_STD_CONFIG std_config = {0};
    DWORD channel = struDeviceInfo.struDeviceV30.byStartChan; // 正确
    // long  channel = struDeviceInfo.struDeviceV30.byStartChan;//错误

    NET_DVR_GIS_INFO gis_info_tmp = {0};
    std_config.lpStatusBuffer = NULL;
    std_config.dwStatusSize = 0;
    std_config.lpOutBuffer = &gis_info_tmp;
    std_config.dwOutSize = sizeof(NET_DVR_GIS_INFO);
    std_config.byDataType = 0;
    std_config.lpCondBuffer = &channel;
    std_config.dwCondSize = sizeof(channel);
    if (!NET_DVR_GetSTDConfig(lHandle, NET_DVR_GET_GISINFO, &std_config))
    {
        std::cout << "failed" << std::endl;
        std::cout << NET_DVR_GetErrorMsg() << std::endl;
        return -1;
    }
    std::cout << "P:" << gis_info_tmp.struPtzPos.fPanPos << std::endl;
    std::cout << "T:" << gis_info_tmp.struPtzPos.fTiltPos << std::endl;
    std::cout << "Z:" << gis_info_tmp.struPtzPos.fZoomPos << std::endl;
    std::cout << "H:" << gis_info_tmp.fHorizontalValue << std::endl;
    std::cout << "V:" << gis_info_tmp.fVerticalValue << std::endl;
    return 0;
}